import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-ef294769/health", (c) => {
  return c.json({ status: "ok" });
});

// ================================================================
// AUTH ROUTES
// ================================================================

app.post("/make-server-ef294769/auth/signup", async (c) => {
  try {
    const { email, password, fullName } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { full_name: fullName || "" },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.error("Error creating user:", error);
      return c.json({ error: error.message }, 400);
    }

    // Get the session for the new user
    const { data: sessionData, error: sessionError } =
      await supabase.auth.signInWithPassword({
        email,
        password,
      });

    if (sessionError) {
      console.error("Error creating session:", sessionError);
      return c.json({ error: sessionError.message }, 400);
    }

    return c.json({
      user: data.user,
      session: sessionData.session,
    });
  } catch (error) {
    console.error("Signup error:", error);
    return c.json({ error: "Internal server error during signup" }, 500);
  }
});

// ================================================================
// ANALYSIS ROUTES
// ================================================================

app.post("/make-server-ef294769/analyses/create", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const analysisData = await c.req.json();

    // Insert the analysis
    const { data, error } = await supabase
      .from("analyses")
      .insert({
        user_id: user.id,
        ...analysisData,
      })
      .select()
      .single();

    if (error) {
      console.error("Error creating analysis:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json(data);
  } catch (error) {
    console.error("Error in create analysis:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

app.get("/make-server-ef294769/analyses/:id", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];
    const analysisId = c.req.param("id");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data, error } = await supabase
      .from("analyses")
      .select("*")
      .eq("id", analysisId)
      .single();

    if (error) {
      console.error("Error fetching analysis:", error);
      return c.json({ error: error.message }, 404);
    }

    return c.json(data);
  } catch (error) {
    console.error("Error in get analysis:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

app.put("/make-server-ef294769/analyses/:id", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];
    const analysisId = c.req.param("id");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const updateData = await c.req.json();

    const { data, error } = await supabase
      .from("analyses")
      .update(updateData)
      .eq("id", analysisId)
      .select()
      .single();

    if (error) {
      console.error("Error updating analysis:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json(data);
  } catch (error) {
    console.error("Error in update analysis:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

app.delete("/make-server-ef294769/analyses/:id", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];
    const analysisId = c.req.param("id");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { error } = await supabase
      .from("analyses")
      .delete()
      .eq("id", analysisId);

    if (error) {
      console.error("Error deleting analysis:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error in delete analysis:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

app.get("/make-server-ef294769/analyses/user/me", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data, error } = await supabase
      .from("analyses")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching user analyses:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json(data || []);
  } catch (error) {
    console.error("Error in get user analyses:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// ================================================================
// PAYMENT ROUTES
// ================================================================

app.post("/make-server-ef294769/payments/create", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { analysisId } = await c.req.json();

    if (!analysisId) {
      return c.json({ error: "Analysis ID is required" }, 400);
    }

    // Check if payment already exists
    const { data: existingPayment } = await supabase
      .from("payments")
      .select("*")
      .eq("analysis_id", analysisId)
      .single();

    if (existingPayment) {
      return c.json({ error: "Payment already exists for this analysis" }, 400);
    }

    // Create payment record (simulated payment - automatically completed)
    const { data: payment, error: paymentError } = await supabase
      .from("payments")
      .insert({
        user_id: user.id,
        analysis_id: analysisId,
        amount_aed: 49.0,
        payment_status: "completed",
        payment_method: "simulated",
        transaction_id: `sim_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      })
      .select()
      .single();

    if (paymentError) {
      console.error("Error creating payment:", paymentError);
      return c.json({ error: paymentError.message }, 400);
    }

    // Update analysis to mark as paid
    const { error: updateError } = await supabase
      .from("analyses")
      .update({ is_paid: true })
      .eq("id", analysisId);

    if (updateError) {
      console.error("Error updating analysis paid status:", updateError);
    }

    return c.json(payment);
  } catch (error) {
    console.error("Error in create payment:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// ================================================================
// ADMIN ROUTES
// ================================================================

app.get("/make-server-ef294769/admin/analytics", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", user.id)
      .single();

    if (!profile?.is_admin) {
      return c.json({ error: "Forbidden - Admin access required" }, 403);
    }

    // Get analytics data
    const { data: analyses } = await supabase.from("analyses").select("*");

    const { data: payments } = await supabase.from("payments").select("*");

    const totalAnalyses = analyses?.length || 0;
    const paidAnalyses = analyses?.filter((a) => a.is_paid).length || 0;
    const totalRevenue =
      payments?.reduce((sum, p) => sum + parseFloat(p.amount_aed), 0) || 0;
    const conversionRate =
      totalAnalyses > 0 ? (paidAnalyses / totalAnalyses) * 100 : 0;

    return c.json({
      totalAnalyses,
      paidAnalyses,
      totalRevenue,
      conversionRate,
      recentAnalyses: analyses?.slice(0, 10) || [],
      recentPayments: payments?.slice(0, 10) || [],
    });
  } catch (error) {
    console.error("Error in admin analytics:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

app.get("/make-server-ef294769/admin/analyses", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", user.id)
      .single();

    if (!profile?.is_admin) {
      return c.json({ error: "Forbidden - Admin access required" }, 403);
    }

    // Get all analyses with user info
    const { data: analyses, error } = await supabase
      .from("analyses")
      .select(`
        *,
        profiles!inner(email, full_name)
      `)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching all analyses:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json(analyses || []);
  } catch (error) {
    console.error("Error in admin get analyses:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

// ================================================================
// PROFILE ROUTES
// ================================================================

app.get("/make-server-ef294769/profile/me", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {
        global: {
          headers: { Authorization: `Bearer ${accessToken}` },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: profile, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    if (error) {
      console.error("Error fetching profile:", error);
      return c.json({ error: error.message }, 404);
    }

    return c.json(profile);
  } catch (error) {
    console.error("Error in get profile:", error);
    return c.json({ error: "Internal server error" }, 500);
  }
});

Deno.serve(app.fetch);